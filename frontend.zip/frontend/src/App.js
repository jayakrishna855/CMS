import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import AdminPage from './components/AdminPage';
import LoginPage from './pages/LoginPage';
// Import other components/pages as needed

function App() {
  return (
    <Router>
      <Switch>
        {/* Define the route for the login page */}
        <Route path="/admin" component={AdminPage} />
        <Route path="/login" component={LoginPage} />
        {/* Add other routes for your project here */}
      </Switch>
    </Router>
  );
}

export default App;