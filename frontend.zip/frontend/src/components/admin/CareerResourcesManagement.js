import React, { useState } from 'react';

const CareerResourcesManagement = () => {
  const [resource, setResource] = useState({
    title: '',
    description: '',
    articles: '',
    guides: '',
    workshops: '',
    webinars: '',
    jobOpportunities: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setResource({ ...resource, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add submission logic here
    console.log('Career Resource:', resource);
  };

  return (
    <div className="career-resources-container">
      <h2>Career Resources Management</h2>
      <form onSubmit={handleSubmit} className="career-resources-form">
        
        <div className="form-group">
          <label>Title <span>*</span></label>
          <input
            type="text"
            name="title"
            value={resource.title}
            onChange={handleInputChange}
            placeholder="Resource Title"
            required
          />
        </div>

        <div className="form-group">
          <label>Description <span>*</span></label>
          <textarea
            name="description"
            value={resource.description}
            onChange={handleInputChange}
            placeholder="Brief description"
            rows="3"
            required
          ></textarea>
        </div>

        <div className="form-group">
          <label>Articles on Career Advancement (Optional)</label>
          <textarea
            name="articles"
            value={resource.articles}
            onChange={handleInputChange}
            placeholder="Links to career articles"
            rows="3"
          ></textarea>
        </div>

        <div className="form-group">
          <label>Guides on Career Advancement (Optional)</label>
          <textarea
            name="guides"
            value={resource.guides}
            onChange={handleInputChange}
            placeholder="Links to career guides"
            rows="3"
          ></textarea>
        </div>

        <div className="form-group">
          <label>Workshops (Optional)</label>
          <textarea
            name="workshops"
            value={resource.workshops}
            onChange={handleInputChange}
            placeholder="Links to workshops"
            rows="3"
          ></textarea>
        </div>

        <div className="form-group">
          <label>Webinars (Optional)</label>
          <textarea
            name="webinars"
            value={resource.webinars}
            onChange={handleInputChange}
            placeholder="Links to webinars"
            rows="3"
          ></textarea>
        </div>

        <div className="form-group">
          <label>Job Board (Optional)</label>
          <textarea
            name="jobOpportunities"
            value={resource.jobOpportunities}
            onChange={handleInputChange}
            placeholder="Links to job opportunities"
            rows="3"
          ></textarea>
        </div>

        <button type="submit" className="submit-btn">Add Resource</button>
      </form>
    </div>
  );
};

export default CareerResourcesManagement;
