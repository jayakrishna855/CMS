import React, { useState } from "react";
import "./CallForPapersManagement.css";

const CallForPapersManagement = ({ conferences }) => {
  const [selectedConference, setSelectedConference] = useState("");
  const [guidelines, setGuidelines] = useState("");
  const [importantDates, setImportantDates] = useState("");
  const [faqList, setFaqList] = useState([]);
  const [newQuestion, setNewQuestion] = useState("");
  const [newAnswer, setNewAnswer] = useState("");

  const handleConferenceChange = (e) => {
    setSelectedConference(e.target.value);

    setGuidelines("");
    setImportantDates("");
    setFaqList([]);
  };

  const handleAddFaq = () => {
    setFaqList([...faqList, { question: newQuestion, answer: newAnswer }]);
    setNewQuestion("");
    setNewAnswer("");
  };

  const handleDeleteFaq = (index) => {
    const updatedFaqs = faqList.filter((_, i) => i !== index);
    setFaqList(updatedFaqs);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log({
      conference: selectedConference,
      guidelines,
      importantDates,
      faqs: faqList,
    });

    setSelectedConference("");
    setGuidelines("");
    setImportantDates("");
    setFaqList([]);
  };

  return (
    <div className="call-for-papers-management">
      <h2>Manage Call for Papers</h2>

      <div className="form-group">
        <label>Select Conference:</label>
        <select
          value={selectedConference}
          onChange={handleConferenceChange}
          required
        >
          <option value="">-- Select Conference --</option>
          {conferences.map((conf, index) => (
            <option key={index} value={conf.name}>
              {conf.name}
            </option>
          ))}
        </select>
      </div>

      <form onSubmit={handleSubmit} className="call-for-papers-form">
        <div className="form-group">
          <label>Submission Guidelines:</label>
          <textarea
            value={guidelines}
            onChange={(e) => setGuidelines(e.target.value)}
            rows="4"
            required
          ></textarea>
        </div>

        <div className="form-group">
          <label>Important Dates:</label>
          <textarea
            value={importantDates}
            onChange={(e) => setImportantDates(e.target.value)}
            rows="3"
            required
          ></textarea>
        </div>

        <div className="faq-section">
          <h3>Manage FAQs</h3>
          <div className="form-group">
            <label>New FAQ Question:</label>
            <input
              type="text"
              value={newQuestion}
              onChange={(e) => setNewQuestion(e.target.value)}
              placeholder="Enter question"
            />
          </div>
          <div className="form-group">
            <label>New FAQ Answer:</label>
            <input
              type="text"
              value={newAnswer}
              onChange={(e) => setNewAnswer(e.target.value)}
              placeholder="Enter answer"
            />
          </div>
          <button type="button" onClick={handleAddFaq}>
            Add FAQ
          </button>

          <ul className="faq-list">
            {faqList.map((faq, index) => (
              <li key={index}>
                <strong>Q: {faq.question}</strong>
                <p>A: {faq.answer}</p>
                <button onClick={() => handleDeleteFaq(index)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>

        <button type="submit">Save Call for Papers</button>
      </form>
    </div>
  );
};

export default CallForPapersManagement;
