import React, { useState } from "react";
import "./UsersManagement.css";

const usersData = [
  { id: 1, email: "user1@example.com", role: "Admin" },
  { id: 2, email: "user2@example.com", role: "Reviewer" },
  { id: 3, email: "user3@example.com", role: "Participant" },
  { id: 4, email: "user3@example.com", role: "Participant" },
  { id: 5, email: "user3@example.com", role: "Participant" },
  { id: 6, email: "user3@example.com", role: "Participant" },
  { id: 7, email: "user3@example.com", role: "Participant" },
];

const UserManagement = () => {
  const [selectedUser, setSelectedUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [role, setRole] = useState("");

  const handleUserSelect = (user) => {
    setSelectedUser(user);
    setRole(user.role);
  };

  const handleRoleUpdate = () => {
    if (selectedUser) {
      console.log(`Updating role of ${selectedUser.email} to ${role}`);
    }
  };

  const filteredUsers = usersData.filter((user) =>
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="user-management">
      <h2>User Management</h2>

      {/* User Search */}
      <div className="search-user">
        <label>Search User by Email:</label>
        <input
          type="text"
          placeholder="Enter email to search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <ul className="user-list">
          {filteredUsers.map((user) => (
            <li key={user.id} onClick={() => handleUserSelect(user)}>
              {user.email}
            </li>
          ))}
        </ul>
      </div>

      {selectedUser && (
        <div className="role-update">
          <h3>Update Role for {selectedUser.email}</h3>
          <label>Current Role:</label>
          <input
            type="text"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          />
          <button onClick={handleRoleUpdate}>Update Role</button>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
