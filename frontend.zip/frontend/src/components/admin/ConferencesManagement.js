import React, { useState } from "react";
import "./ConferenceManagement.css";

const ConferenceManagement = ({ conferences }) => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [location, setLocation] = useState("");
  const [totalTickets, setTotalTickets] = useState(0);
  const [ticketTypes, setTicketTypes] = useState([{ type: "", price: "" }]);
  const [selectedConference, setSelectedConference] = useState(null);

  const handleAddTicketType = () => {
    setTicketTypes([...ticketTypes, { type: "", price: "" }]);
  };

  const handleTicketTypeChange = (index, field, value) => {
    const updatedTickets = ticketTypes.map((ticket, i) =>
      i === index ? { ...ticket, [field]: value } : ticket
    );
    setTicketTypes(updatedTickets);
  };

  const handleDeleteTicketType = (index) => {
    const updatedTickets = ticketTypes.filter((_, i) => i !== index);
    setTicketTypes(updatedTickets);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const conferenceData = {
      name,
      description,
      startDate,
      endDate,
      location,
      totalTickets,
      ticketTypes,
    };

    console.log(conferenceData);

    setName("");
    setDescription("");
    setStartDate("");
    setEndDate("");
    setLocation("");
    setTotalTickets(0);
    setTicketTypes([{ type: "", price: "" }]);
  };

  return (
    <div className="conference-management">
      <h2>Manage Conference</h2>

      <form onSubmit={handleSubmit} className="conference-form">
        <div className="form-group">
          <label>Conference Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Description:</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          ></textarea>
        </div>

        <div className="form-group">
          <label>Start Date:</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>End Date:</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Location:</label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Total Number of Tickets:</label>
          <input
            type="number"
            value={totalTickets}
            onChange={(e) => setTotalTickets(e.target.value)}
            required
          />
        </div>

        <div className="ticket-section">
          <h3>Manage Ticket Types</h3>
          {ticketTypes.map((ticket, index) => (
            <div key={index} className="ticket-type-row">
              <div className="form-group">
                <label>Ticket Type:</label>
                <input
                  type="text"
                  value={ticket.type}
                  onChange={(e) =>
                    handleTicketTypeChange(index, "type", e.target.value)
                  }
                  required
                />
              </div>
              <div className="form-group">
                <label>Price:</label>
                <input
                  type="number"
                  value={ticket.price}
                  onChange={(e) =>
                    handleTicketTypeChange(index, "price", e.target.value)
                  }
                  required
                />
              </div>
              <button
                type="button"
                onClick={() => handleDeleteTicketType(index)}
              >
                Delete Ticket Type
              </button>
            </div>
          ))}
          <button type="button" onClick={handleAddTicketType}>
            Add Ticket Type
          </button>
        </div>

        <button type="submit">Save Conference</button>
      </form>

      <div className="conference-list">
        <h3>Available Conferences</h3>
        <table className="conference-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Location</th>
              <th>Total Tickets</th>
              <th>Ticket Types and Prices</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {conferences.map((conference, index) => (
              <tr key={index}>
                <td>{conference.name}</td>
                <td>{conference.description}</td>
                <td>{conference.startDate}</td>
                <td>{conference.endDate}</td>
                <td>{conference.location}</td>
                <td>{conference.totalTickets}</td>
                <td>
                  {conference.ticketTypes.map((ticket, i) => (
                    <div key={i}>
                      {ticket.type}: ${ticket.price}
                    </div>
                  ))}
                </td>
                <td>
                  <button>Edit</button>
                  <button>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ConferenceManagement;
