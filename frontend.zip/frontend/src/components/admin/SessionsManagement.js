import React, { useState } from "react";
import "./SessionsManagement.css";

const conferencesData = [
  { id: 1, name: "Conference 1" },
  { id: 2, name: "Conference 2" },
];

const initialSessionsData = {
  1: [
    {
      id: 1,
      agenda: "Session 1 Agenda",
      presentationTopics: "Topic 1, Topic 2",
      speaker: "Speaker 1",
      startTime: "2024-10-10T09:00",
      endTime: "2024-10-10T10:00",
      liveStreamingLink: "https://livestream.com/session1",
      recordingLink: "https://recordings.com/session1",
    },
  ],
  2: [],
};

const SessionsManagement = () => {
  const [selectedConference, setSelectedConference] = useState("");
  const [agenda, setAgenda] = useState("");
  const [presentationTopics, setPresentationTopics] = useState("");
  const [speaker, setSpeaker] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [liveStreamingLink, setLiveStreamingLink] = useState("");
  const [recordingLink, setRecordingLink] = useState("");
  const [sessionsData, setSessionsData] = useState(initialSessionsData);

  const handleConferenceChange = (event) => {
    setSelectedConference(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!selectedConference) {
      alert("Please select a conference.");
      return;
    }

    const newSession = {
      id: Date.now(), // Unique ID for each new session
      agenda,
      presentationTopics,
      speaker,
      startTime,
      endTime,
      liveStreamingLink,
      recordingLink,
    };

    setSessionsData((prevData) => ({
      ...prevData,
      [selectedConference]: [...prevData[selectedConference], newSession],
    }));

    // Clear form fields after submission
    setAgenda("");
    setPresentationTopics("");
    setSpeaker("");
    setStartTime("");
    setEndTime("");
    setLiveStreamingLink("");
    setRecordingLink("");
  };

  const handleDeleteSession = (sessionId) => {
    setSessionsData((prevData) => ({
      ...prevData,
      [selectedConference]: prevData[selectedConference].filter(
        (session) => session.id !== sessionId
      ),
    }));
  };

  const handleEditSession = (session) => {
    setAgenda(session.agenda);
    setPresentationTopics(session.presentationTopics);
    setSpeaker(session.speaker);
    setStartTime(session.startTime);
    setEndTime(session.endTime);
    setLiveStreamingLink(session.liveStreamingLink);
    setRecordingLink(session.recordingLink);
  };

  return (
    <div className="session-management">
      <h2>Session Management</h2>
      <form onSubmit={handleSubmit}>
        {/* Select Conference */}
        <div className="form-group">
          <label>Select Conference:</label>
          <select
            value={selectedConference}
            onChange={handleConferenceChange}
            required
          >
            <option value="">-- Select Conference --</option>
            {conferencesData.map((conference) => (
              <option key={conference.id} value={conference.id}>
                {conference.name}
              </option>
            ))}
          </select>
        </div>

        {/* Agenda */}
        <div className="form-group">
          <label>Agenda:</label>
          <input
            type="text"
            value={agenda}
            onChange={(e) => setAgenda(e.target.value)}
            required
          />
        </div>

        {/* Presentation Topics (Text Area) */}
        <div className="form-group">
          <label>Presentation Topics:</label>
          <textarea
            value={presentationTopics}
            onChange={(e) => setPresentationTopics(e.target.value)}
            required
          />
        </div>

        {/* Speaker */}
        <div className="form-group">
          <label>Speaker:</label>
          <input
            type="text"
            value={speaker}
            onChange={(e) => setSpeaker(e.target.value)}
            required
          />
        </div>

        {/* Start Time */}
        <div className="form-group">
          <label>Start Time:</label>
          <input
            type="datetime-local"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            required
          />
        </div>

        {/* End Time */}
        <div className="form-group">
          <label>End Time:</label>
          <input
            type="datetime-local"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
            required
          />
        </div>

        {/* Live Streaming Link (Optional) */}
        <div className="form-group">
          <label>Live Streaming Link (Optional):</label>
          <input
            type="url"
            value={liveStreamingLink}
            onChange={(e) => setLiveStreamingLink(e.target.value)}
          />
        </div>

        {/* Recording Link (Optional) */}
        <div className="form-group">
          <label>Recording Link (Optional):</label>
          <input
            type="url"
            value={recordingLink}
            onChange={(e) => setRecordingLink(e.target.value)}
          />
        </div>

        <button type="submit">Save Session</button>
      </form>

      {/* Display Existing Sessions for the Selected Conference */}
      {selectedConference && sessionsData[selectedConference].length > 0 && (
        <div className="existing-sessions">
          <h3>
            Existing Sessions for{" "}
            {
              conferencesData.find((conf) => conf.id == selectedConference)
                ?.name
            }
            :
          </h3>
          <table>
            <thead>
              <tr>
                <th>Agenda</th>
                <th>Topics</th>
                <th>Speaker</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Live Streaming Link</th>
                <th>Recording Link</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sessionsData[selectedConference].map((session) => (
                <tr key={session.id}>
                  <td>{session.agenda}</td>
                  <td>{session.presentationTopics}</td>
                  <td>{session.speaker}</td>
                  <td>{session.startTime}</td>
                  <td>{session.endTime}</td>
                  <td>
                    {session.liveStreamingLink
                      ? session.liveStreamingLink
                      : "N/A"}
                  </td>
                  <td>
                    {session.recordingLink ? session.recordingLink : "N/A"}
                  </td>
                  <td>
                    <button onClick={() => handleEditSession(session)}>
                      Edit
                    </button>
                    <button onClick={() => handleDeleteSession(session.id)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default SessionsManagement;
