import React, { useState } from "react";
import {
  Drawer,
  AppBar,
  Toolbar,
  List,
  ListItem,
  ListItemText,
  Typography,
  Box,
  Button,
} from "@mui/material";
import ConferencesManagement from "./admin/ConferencesManagement";
import CallForPapersManagement from "./admin/CallForPapersManagement";
import SessionsManagement from "./admin/SessionsManagement";
import MentorsManagement from "./admin/MentorsManagement";
import CareerResourcesManagement from "./admin/CareerResourcesManagement";
import UsersManagement from "./admin/UsersManagement";

const drawerWidth = 240;

const conferences = [
  {
    name: "Conference 1",
    description: "Description 1",
    startDate: "2024-11-01",
    endDate: "2024-11-03",
    location: "Location 1",
    totalTickets: 500,
    ticketTypes: [
      { type: "Regular", price: 100 },
      { type: "VIP", price: 250 },
    ],
  },
  {
    name: "Conference 2",
    description: "Description 2",
    startDate: "2024-12-01",
    endDate: "2024-12-05",
    location: "Location 2",
    totalTickets: 300,
    ticketTypes: [
      { type: "Student", price: 50 },
      { type: "Regular", price: 150 },
    ],
  },
];

const AdminPage = () => {
  const [selectedSection, setSelectedSection] = useState("conferences");
  //   const [conferences, setConferences] = useState([
  //     { name: 'Conference 1' },
  //     { name: 'Conference 2' },
  //     { name: 'Conference 3' },
  //   ]);

  const handleSignOut = () => {};

  const renderSection = () => {
    switch (selectedSection) {
      case "conferences":
        return <ConferencesManagement conferences={conferences} />;
      case "callForPapers":
        return <CallForPapersManagement conferences={conferences} />;
      case "sessions":
        return <SessionsManagement/>;
      case "mentors":
        return <MentorsManagement/>;
      case "users":
        return <UsersManagement />;
      case "resources":
        return <CareerResourcesManagement/>

      default:
        return <ConferencesManagement />;
    }
  };

  return (
    <Box sx={{ display: "flex" }}>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: "auto" }}>
          <List>
            <ListItem button onClick={() => setSelectedSection("conferences")}>
              <ListItemText primary="Conferences" />
            </ListItem>
            <ListItem
              button
              onClick={() => setSelectedSection("callForPapers")}
            >
              <ListItemText primary="Call for Papers" />
            </ListItem>
            <ListItem button onClick={() => setSelectedSection("sessions")}>
              <ListItemText primary="Sessions" />
            </ListItem>
            <ListItem button onClick={() => setSelectedSection("mentors")}>
              <ListItemText primary="Mentors" />
            </ListItem>
            <ListItem button onClick={() => setSelectedSection("resources")}>
              <ListItemText primary="CareerResources" />
            </ListItem>
            <ListItem button onClick={() => setSelectedSection("users")}>
              <ListItemText primary="Users" />
            </ListItem>
          </List>
        </Box>
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <AppBar
          position="fixed"
          sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}
        >
          <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
            <Typography variant="h6" noWrap component="div">
              Admin Panel - Conference Management System
            </Typography>

            <Button color="inherit" onClick={handleSignOut}>
              Sign Out
            </Button>
          </Toolbar>
        </AppBar>

        <Toolbar />

        {renderSection()}
      </Box>
    </Box>
  );
};

export default AdminPage;
